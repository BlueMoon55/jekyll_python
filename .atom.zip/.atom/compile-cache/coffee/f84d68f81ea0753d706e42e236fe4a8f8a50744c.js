(function() {
  var AnsiToHtml, AtomRunnerView, ScrollView,
    extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
    hasProp = {}.hasOwnProperty;

  ScrollView = require('atom-space-pen-views').ScrollView;

  AnsiToHtml = require('ansi-to-html');

  module.exports = AtomRunnerView = (function(superClass) {
    extend(AtomRunnerView, superClass);

    atom.deserializers.add(AtomRunnerView);

    AtomRunnerView.deserialize = function(arg) {
      var footer, output, title, view;
      title = arg.title, output = arg.output, footer = arg.footer;
      view = new AtomRunnerView(title);
      view._output.html(output);
      view._footer.html(footer);
      return view;
    };

    AtomRunnerView.content = function() {
      return this.div({
        "class": 'atom-runner',
        tabindex: -1
      }, (function(_this) {
        return function() {
          _this.h1('Atom Runner');
          _this.pre({
            "class": 'output'
          });
          return _this.div({
            "class": 'footer'
          });
        };
      })(this));
    };

    function AtomRunnerView(title) {
      AtomRunnerView.__super__.constructor.apply(this, arguments);
      this._output = this.find('.output');
      this._footer = this.find('.footer');
      this.setTitle(title);
    }

    AtomRunnerView.prototype.serialize = function() {
      return {
        deserializer: 'AtomRunnerView',
        title: this.title,
        output: this._output.html(),
        footer: this._footer.html()
      };
    };

    AtomRunnerView.prototype.getTitle = function() {
      return "Atom Runner: " + this.title;
    };

    AtomRunnerView.prototype.setTitle = function(title) {
      this.title = title;
      return this.find('h1').html(this.getTitle());
    };

    AtomRunnerView.prototype.clear = function() {
      this._output.html('');
      return this._footer.html('');
    };

    AtomRunnerView.prototype.append = function(text, className) {
      var node, span;
      span = document.createElement('span');
      node = document.createTextNode(text);
      span.appendChild(node);
      span.innerHTML = new AnsiToHtml().toHtml(span.innerHTML);
      span.className = className || 'stdout';
      return this._output.append(span);
    };

    AtomRunnerView.prototype.appendFooter = function(text) {
      return this._footer.html(this._footer.html() + text);
    };

    AtomRunnerView.prototype.footer = function(text) {
      return this._footer.html(text);
    };

    return AtomRunnerView;

  })(ScrollView);

}).call(this);

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiZmlsZTovLy9DOi9Vc2Vycy90NjAxNDI1MC8uYXRvbS9wYWNrYWdlcy9hdG9tLXJ1bm5lci1tYXN0ZXIvbGliL2F0b20tcnVubmVyLXZpZXcuY29mZmVlIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0FBQUEsTUFBQSxzQ0FBQTtJQUFBOzs7RUFBQyxhQUFjLE9BQUEsQ0FBUSxzQkFBUjs7RUFDZixVQUFBLEdBQWEsT0FBQSxDQUFRLGNBQVI7O0VBRWIsTUFBTSxDQUFDLE9BQVAsR0FDTTs7O0lBQ0osSUFBSSxDQUFDLGFBQWEsQ0FBQyxHQUFuQixDQUF1QixjQUF2Qjs7SUFFQSxjQUFDLENBQUEsV0FBRCxHQUFjLFNBQUMsR0FBRDtBQUNaLFVBQUE7TUFEYyxtQkFBTyxxQkFBUTtNQUM3QixJQUFBLEdBQU8sSUFBSSxjQUFKLENBQW1CLEtBQW5CO01BQ1AsSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFiLENBQWtCLE1BQWxCO01BQ0EsSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFiLENBQWtCLE1BQWxCO2FBQ0E7SUFKWTs7SUFNZCxjQUFDLENBQUEsT0FBRCxHQUFVLFNBQUE7YUFDUixJQUFDLENBQUEsR0FBRCxDQUFLO1FBQUEsQ0FBQSxLQUFBLENBQUEsRUFBTyxhQUFQO1FBQXNCLFFBQUEsRUFBVSxDQUFDLENBQWpDO09BQUwsRUFBeUMsQ0FBQSxTQUFBLEtBQUE7ZUFBQSxTQUFBO1VBQ3ZDLEtBQUMsQ0FBQSxFQUFELENBQUksYUFBSjtVQUNBLEtBQUMsQ0FBQSxHQUFELENBQUs7WUFBQSxDQUFBLEtBQUEsQ0FBQSxFQUFPLFFBQVA7V0FBTDtpQkFDQSxLQUFDLENBQUEsR0FBRCxDQUFLO1lBQUEsQ0FBQSxLQUFBLENBQUEsRUFBTyxRQUFQO1dBQUw7UUFIdUM7TUFBQSxDQUFBLENBQUEsQ0FBQSxJQUFBLENBQXpDO0lBRFE7O0lBTUcsd0JBQUMsS0FBRDtNQUNYLGlEQUFBLFNBQUE7TUFFQSxJQUFDLENBQUEsT0FBRCxHQUFXLElBQUMsQ0FBQSxJQUFELENBQU0sU0FBTjtNQUNYLElBQUMsQ0FBQSxPQUFELEdBQVcsSUFBQyxDQUFBLElBQUQsQ0FBTSxTQUFOO01BQ1gsSUFBQyxDQUFBLFFBQUQsQ0FBVSxLQUFWO0lBTFc7OzZCQU9iLFNBQUEsR0FBVyxTQUFBO2FBQ1Q7UUFBQSxZQUFBLEVBQWMsZ0JBQWQ7UUFDQSxLQUFBLEVBQU8sSUFBQyxDQUFBLEtBRFI7UUFFQSxNQUFBLEVBQVEsSUFBQyxDQUFBLE9BQU8sQ0FBQyxJQUFULENBQUEsQ0FGUjtRQUdBLE1BQUEsRUFBUSxJQUFDLENBQUEsT0FBTyxDQUFDLElBQVQsQ0FBQSxDQUhSOztJQURTOzs2QkFNWCxRQUFBLEdBQVUsU0FBQTthQUNSLGVBQUEsR0FBZ0IsSUFBQyxDQUFBO0lBRFQ7OzZCQUdWLFFBQUEsR0FBVSxTQUFDLEtBQUQ7TUFDUixJQUFDLENBQUEsS0FBRCxHQUFTO2FBQ1QsSUFBQyxDQUFBLElBQUQsQ0FBTSxJQUFOLENBQVcsQ0FBQyxJQUFaLENBQWlCLElBQUMsQ0FBQSxRQUFELENBQUEsQ0FBakI7SUFGUTs7NkJBSVYsS0FBQSxHQUFPLFNBQUE7TUFDTCxJQUFDLENBQUEsT0FBTyxDQUFDLElBQVQsQ0FBYyxFQUFkO2FBQ0EsSUFBQyxDQUFBLE9BQU8sQ0FBQyxJQUFULENBQWMsRUFBZDtJQUZLOzs2QkFJUCxNQUFBLEdBQVEsU0FBQyxJQUFELEVBQU8sU0FBUDtBQUNOLFVBQUE7TUFBQSxJQUFBLEdBQU8sUUFBUSxDQUFDLGFBQVQsQ0FBdUIsTUFBdkI7TUFDUCxJQUFBLEdBQU8sUUFBUSxDQUFDLGNBQVQsQ0FBd0IsSUFBeEI7TUFDUCxJQUFJLENBQUMsV0FBTCxDQUFpQixJQUFqQjtNQUNBLElBQUksQ0FBQyxTQUFMLEdBQWlCLElBQUksVUFBSixDQUFBLENBQWdCLENBQUMsTUFBakIsQ0FBd0IsSUFBSSxDQUFDLFNBQTdCO01BQ2pCLElBQUksQ0FBQyxTQUFMLEdBQWlCLFNBQUEsSUFBYTthQUM5QixJQUFDLENBQUEsT0FBTyxDQUFDLE1BQVQsQ0FBZ0IsSUFBaEI7SUFOTTs7NkJBUVIsWUFBQSxHQUFjLFNBQUMsSUFBRDthQUNaLElBQUMsQ0FBQSxPQUFPLENBQUMsSUFBVCxDQUFjLElBQUMsQ0FBQSxPQUFPLENBQUMsSUFBVCxDQUFBLENBQUEsR0FBa0IsSUFBaEM7SUFEWTs7NkJBR2QsTUFBQSxHQUFRLFNBQUMsSUFBRDthQUNOLElBQUMsQ0FBQSxPQUFPLENBQUMsSUFBVCxDQUFjLElBQWQ7SUFETTs7OztLQWxEbUI7QUFKN0IiLCJzb3VyY2VzQ29udGVudCI6WyJ7U2Nyb2xsVmlld30gPSByZXF1aXJlICdhdG9tLXNwYWNlLXBlbi12aWV3cydcbkFuc2lUb0h0bWwgPSByZXF1aXJlICdhbnNpLXRvLWh0bWwnXG5cbm1vZHVsZS5leHBvcnRzID1cbmNsYXNzIEF0b21SdW5uZXJWaWV3IGV4dGVuZHMgU2Nyb2xsVmlld1xuICBhdG9tLmRlc2VyaWFsaXplcnMuYWRkKHRoaXMpXG5cbiAgQGRlc2VyaWFsaXplOiAoe3RpdGxlLCBvdXRwdXQsIGZvb3Rlcn0pIC0+XG4gICAgdmlldyA9IG5ldyBBdG9tUnVubmVyVmlldyh0aXRsZSlcbiAgICB2aWV3Ll9vdXRwdXQuaHRtbChvdXRwdXQpXG4gICAgdmlldy5fZm9vdGVyLmh0bWwoZm9vdGVyKVxuICAgIHZpZXdcblxuICBAY29udGVudDogLT5cbiAgICBAZGl2IGNsYXNzOiAnYXRvbS1ydW5uZXInLCB0YWJpbmRleDogLTEsID0+XG4gICAgICBAaDEgJ0F0b20gUnVubmVyJ1xuICAgICAgQHByZSBjbGFzczogJ291dHB1dCdcbiAgICAgIEBkaXYgY2xhc3M6ICdmb290ZXInXG5cbiAgY29uc3RydWN0b3I6ICh0aXRsZSkgLT5cbiAgICBzdXBlclxuXG4gICAgQF9vdXRwdXQgPSBAZmluZCgnLm91dHB1dCcpXG4gICAgQF9mb290ZXIgPSBAZmluZCgnLmZvb3RlcicpXG4gICAgQHNldFRpdGxlKHRpdGxlKVxuXG4gIHNlcmlhbGl6ZTogLT5cbiAgICBkZXNlcmlhbGl6ZXI6ICdBdG9tUnVubmVyVmlldydcbiAgICB0aXRsZTogQHRpdGxlXG4gICAgb3V0cHV0OiBAX291dHB1dC5odG1sKClcbiAgICBmb290ZXI6IEBfZm9vdGVyLmh0bWwoKVxuXG4gIGdldFRpdGxlOiAtPlxuICAgIFwiQXRvbSBSdW5uZXI6ICN7QHRpdGxlfVwiXG5cbiAgc2V0VGl0bGU6ICh0aXRsZSkgLT5cbiAgICBAdGl0bGUgPSB0aXRsZVxuICAgIEBmaW5kKCdoMScpLmh0bWwoQGdldFRpdGxlKCkpXG5cbiAgY2xlYXI6IC0+XG4gICAgQF9vdXRwdXQuaHRtbCgnJylcbiAgICBAX2Zvb3Rlci5odG1sKCcnKVxuXG4gIGFwcGVuZDogKHRleHQsIGNsYXNzTmFtZSkgLT5cbiAgICBzcGFuID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnc3BhbicpXG4gICAgbm9kZSA9IGRvY3VtZW50LmNyZWF0ZVRleHROb2RlKHRleHQpXG4gICAgc3Bhbi5hcHBlbmRDaGlsZChub2RlKVxuICAgIHNwYW4uaW5uZXJIVE1MID0gbmV3IEFuc2lUb0h0bWwoKS50b0h0bWwoc3Bhbi5pbm5lckhUTUwpXG4gICAgc3Bhbi5jbGFzc05hbWUgPSBjbGFzc05hbWUgfHwgJ3N0ZG91dCdcbiAgICBAX291dHB1dC5hcHBlbmQoc3BhbilcbiAgXG4gIGFwcGVuZEZvb3RlcjogKHRleHQpIC0+XG4gICAgQF9mb290ZXIuaHRtbChAX2Zvb3Rlci5odG1sKCkgKyB0ZXh0KVxuXG4gIGZvb3RlcjogKHRleHQpIC0+XG4gICAgQF9mb290ZXIuaHRtbCh0ZXh0KVxuIl19
